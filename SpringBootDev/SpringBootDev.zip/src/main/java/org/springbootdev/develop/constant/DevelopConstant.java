
package org.springbootdev.develop.constant;

/**
 * 系统常量.
 *
 * @author zhaobohao
 */
public interface DevelopConstant {
	/**
	 * vue element admin 系统名
	 */
	String WEB_VUE_NAME = "vue element admin";

}

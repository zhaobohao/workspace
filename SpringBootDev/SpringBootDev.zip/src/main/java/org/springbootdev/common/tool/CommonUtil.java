
package org.springbootdev.common.tool;

/**
 * 通用工具类
 *
 * @author merryChen
 */
public class CommonUtil {

}

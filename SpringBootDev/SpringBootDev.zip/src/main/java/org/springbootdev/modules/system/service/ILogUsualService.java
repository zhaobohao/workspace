
package org.springbootdev.modules.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.springbootdev.core.log.model.LogUsual;

/**
 * 服务类
 *
 * @author merryChen
 */
public interface ILogUsualService extends IService<LogUsual> {

}

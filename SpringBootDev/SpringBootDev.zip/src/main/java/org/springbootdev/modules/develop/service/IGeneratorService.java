package org.springbootdev.modules.develop.service;

/**
 * 代码自动生成器
 * @author zhaobo
 * @date
 */
public interface IGeneratorService {
    /**
     * 生成ddl文件
      * @param ids
     * @return
     */
    byte[] generatorDdlFile(String ids) throws Exception;
}

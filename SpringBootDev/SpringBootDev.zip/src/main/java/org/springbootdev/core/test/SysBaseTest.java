

package org.springbootdev.core.test;

import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

/**
 * boot test 基类
 *
 * @author zhaobohao
 */
@RunWith(SysSpringRunner.class)
public abstract class SysBaseTest extends AbstractJUnit4SpringContextTests {

}


package org.springbootdev.core.tool.utils;

/**
 * 生成的随机数类型
 *
 * @author zhaobohao
 */
public enum RandomType {
	/**
	 * INT STRING ALL
	 */
	INT, STRING, ALL
}

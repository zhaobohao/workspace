

package org.springbootdev.core.test;

/**
 *  test 异常
 *
 * @author zhaobohao
 */
class BootTestException extends RuntimeException {

	BootTestException(String message) {
		super(message);
	}
}
